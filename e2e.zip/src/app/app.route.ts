import { Routes } from '@angular/router';
import { IndexComponent } from './index';
import { AppLayout } from './layouts/app-layout';
import { AuthLayout } from './layouts/auth-layout';

export const routes: Routes = [
  {
    path: '',
    component: AppLayout,
    children: [
      {
        path: '',
        component: IndexComponent,
        data: { title: 'Vendedores Admin' },
      },
    ],
  },
  {
    path: '',
    component: AuthLayout,
    children: [],
  },
];
